<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('پنل ادمین')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>


                            <div class="row">
                                <div class="col-12">
                                    <div class="list-group" id="list-tab" role="">
                                        <a class="list-group-item list-group-item-action" id="list-settings-list"  href="<?php echo e(route('register')); ?>" role="tab" >ثبت کاربر جدید</a>
                                        <a class="list-group-item list-group-item-action" id="list-settings-list"  href="<?php echo e(route('users')); ?>" role="tab" >نمایش کاربران</a>
                                    </div>
                                </div>
                            </div>



                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\PhpstormProjects\amlak\resources\views/Admin/admin.blade.php ENDPATH**/ ?>