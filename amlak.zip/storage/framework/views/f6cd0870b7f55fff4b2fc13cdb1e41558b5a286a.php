<style>


</style>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="card-group justify-content-between">
                            <label class="fw-bold" style="font-size: large">نام مالک:</label>
                            <label class="w-50"><?php echo e($estate->owner_name); ?></label>
                        </div>

                        <br>

                        <div class="card-group justify-content-between">
                            <label class="fw-bold" style="font-size: large">شماره تماس:</label>
                            <label class="w-50"><?php echo e($estate->owner_phone); ?></label>
                        </div>
                        <hr>
                        <div class="card-group justify-content-between">
                            <label class="fw-bold" style=" font-size: large">نوع ملک:</label>
                            <label class="w-50"><?php echo e($estate->estate_type->name); ?></label>

                        </div>
                        <hr>
                        <?php if(!empty($estate->building_type_id)): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">وضعیت ملک :</label>
                                <label class="w-50"><?php echo e($estate->building_type->name); ?></label>
                            </div>
                            <hr>
                        <?php endif; ?>

                        <div class="card-group justify-content-between">
                            <label class="fw-bold" style="font-size: large">شهر:</label>
                            <label class="w-50"><?php echo e($estate->city->name); ?></label>

                        </div>
                        <br>
                        <div class="card-group justify-content-between">
                            <label class="fw-bold" style="font-size: large">منطقه:</label>
                            <label class="w-50"><?php echo e($estate->location->name); ?></label>
                        </div>
                        <br>

                        <div class="card-group justify-content-between">
                            <label class="fw-bold" style="font-size: large">قیمت:</label>
                            <label class="w-50"><?php echo e($estate->price); ?></label>
                        </div>
                        <hr>

                        <?php if(!empty($estate->area)): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">متراژ زمین:</label>
                                <label class="w-50"><?php echo e($estate->area); ?></label>
                            </div>
                            <hr>
                        <?php endif; ?>

                        <?php if(!empty($estate->building_area)): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">متراژ بنا:</label>
                                <label class="w-50"><?php echo e($estate->building_area); ?></label>
                            </div>
                            <hr>
                        <?php endif; ?>
                        <?php if(!empty($estate->building_date)): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">سال ساخت:</label>
                                <label class="w-50"><?php echo e($estate->building_date); ?></label>
                            </div>
                            <hr>
                        <?php endif; ?>

                        <?php if(!empty($estate->length)): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">طول:</label>
                                <label class="w-50"><?php echo e($estate->length); ?></label>
                            </div>
                            <hr>
                        <?php endif; ?>
                        <?php if(!empty($estate->width)): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">عرض:</label>
                                <label class="w-50"><?php echo e($estate->width); ?></label>
                            </div>
                            <hr>
                        <?php endif; ?>

                        <?php if($estate->options!='[]'): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">مشاعات:</label>
                                <label class="w-50">
                                    <?php $__currentLoopData = $estate->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($option->name); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </label>
                            </div>
                            <hr>
                        <?php endif; ?>

                        <?php if($estate->used_type!='[]'): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">نوع کاربری:</label>
                                <label class="w-50">
                                    <?php $__currentLoopData = $estate->used_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $used): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($used->name); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </label>
                            </div>
                            <hr>
                        <?php endif; ?>
                        <?php if($estate->conditions_type!='[]'): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">شرایط قیمت:</label>
                                <label class="w-50">
                                    <?php $__currentLoopData = $estate->conditions_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($condition->name); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </label>
                            </div>
                            <hr>
                        <?php endif; ?>
                        <?php if($estate->documents!='[]'): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">مدارک:</label>
                                <label class="w-50">
                                    <?php $__currentLoopData = $estate->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($document->name); ?> ,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </label>
                            </div>
                            <hr>
                        <?php endif; ?>
                        <?php if($estate->vila_options!='[]'): ?>


                            <div class=" card-group justify-content-between">
                                <label class="fw-bold" style="font-size: large">مشاعات ویلا:</label>
                                <label class="w-50">
                                    <?php $__currentLoopData = $estate->vila_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vila_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($vila_option->name); ?> ,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </label>
                            </div>
                            <hr>
                        <?php endif; ?>


                        <div class="card-group justify-content-between">
                            <label class="fw-bold" style="font-size: large">آدرس:</label>
                            <label class="w-50"><?php echo e($estate->address); ?></label>
                        </div>
                        <hr>
                        <div class=" card-group justify-content-between">
                            <label class="fw-bold" style="font-size: large">توضیحات:</label>
                            <label class="w-50"><?php echo e($estate->description); ?></label>
                        </div>

                            <hr>

                        <div class="">
                            <label class="fw-bold" style="font-size: large">تصاویر:</label>
<br>
                            <div id="parent" class="row row-cols-2" >
                                <?php $__currentLoopData = $estate->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <img id="child" class="custom"  src="<?php echo e(asset('images/'.$image->file_name)); ?> " width="200" height="200">


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\PhpstormProjects\amlak\resources\views/attract/get_estate.blade.php ENDPATH**/ ?>