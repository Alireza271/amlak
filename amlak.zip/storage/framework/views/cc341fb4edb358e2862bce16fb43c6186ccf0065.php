<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header "><?php echo e(__('لیست کاربران')); ?>

                        <form method="GET" action=<?php echo e(route("search_user")); ?>>
                            <div class="input-group float-right col-md-6 row">
                                <button class="btn btn-outline-secondary" type="submit" id="button-addon1">جستجو
                                </button>
                                <input name="query" type="text" class="form-control" placeholder=""
                                       aria-label="Example text with button addon" aria-describedby="button-addon1">
                            </div>

                        </form>
                    </div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <table class="table " style="direction: rtl">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">نام</th>
                                <th scope="col">تلفن</th>
                                <th scope="col">تاریخ عضویت</th>
                                <th scope="col">سمت</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <th scope="row"><?php echo e($i++); ?></th>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->phone); ?></td>
                                    <td><?php echo e(\Morilog\Jalali\CalendarUtils::strftime('%A, %d %B %y', strtotime($user->created_at))); ?></td>
                                    <?php if($user->is_admin): ?>
                                        <td>
                                            <button type="button" class="btn btn-primary">مدیر</button>
                                            <?php endif; ?>
                                        </td>
                                        <?php if($user->is_attract): ?>
                                            <td>
                                                <button type="button" class="btn btn-success">جذب</button>

                                            </td>
                                        <?php endif; ?>
                                        <?php if($user->is_circulation): ?>
                                            <td>
                                                <button type="button" class="btn btn-warning">گردش</button>

                                            </td>

                                        <?php endif; ?>


                                        <td>
                                            <a type="button" class="btn btn-danger" onclick="function ff(id){

                                                if(confirm('آیا میخواهید ادامه دهید؟')) {
                                                window.location.href ='/Admin/users/delete/'+id

                                                }
                                                }


                                                ff(<?php echo e($user->id); ?>);
                                                "
                                            >حذف</a>
                                            <a type="button" class="btn btn-info"
                                               href="<?php echo e(route("update_user_page",["id"=>$user->id])); ?>">ویرایش</a>

                                        </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\PhpstormProjects\amlak\resources\views/Admin/users.blade.php ENDPATH**/ ?>