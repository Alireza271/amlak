<style>
    .pagination {
        display: flex;
        justify-content: center;
    }

    .pagination li {
        display: block;
    }
</style>

<?php $__env->startSection('content'); ?>

    <div class="container ">
        <a class="btn btn-success" href="<?php echo e(route("attract")); ?>">بازگشت</a>

        <div class="card">

            <div class="card-header">

                <div class="card-header "><?php echo e(__('املاک ثبت شده')); ?>


                </div>

                <form method="GET" action="<?php echo e(route('search_estate')); ?>">

                    <div class="input-group float-right col-12 ">
                        <div class="card-group">
                            <div class="container">
                                <div class="row row-cols-xl-3-1  row-cols-lg-2 row-cols-md-2 row-cols-sm-1">
                                    <div>

                                        <?php if(request('lock')): ?>
                                            <input type="hidden" value="1" name="lock">
                                        <?php endif; ?>

                                        <input value="<?php echo e(request('query')); ?>" name="query" type="text"
                                               class="form-control"
                                               placeholder="جستجو...">
                                    </div>


                                    <div>
                                        <select id="building_type" name="building_type"
                                                class="form-select">
                                            <option value="">یکی از گزینه هارا انتخاب کنید</option>

                                            <?php $__currentLoopData = \App\Models\building_type::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(request("building_type")==$type->id): ?> selected
                                                        <?php endif; ?> value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div>
                                        <select id="estate_location_type" name="estate_location_type"
                                                class="form-select">
                                            <option value="">یکی از گزینه هارا انتخاب کنید</option>

                                            <?php $__currentLoopData = \App\Models\Estate_Location_type::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(request("estate_location_type")==$type->id): ?> selected
                                                        <?php endif; ?> value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>


                                    <div>
                                        <select id="city_dropdown" name="city" class="form-select">
                                            <option value="">یکی از شهر ها را انتخاب کنید</option>

                                            <?php $__currentLoopData = \App\Models\City::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(request("city")==$city->id): ?> selected
                                                        <?php endif; ?> value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div>
                                        <select id="location_dropdown" name="location" class="form-select">
                                            <option value=''></option>
                                        </select>

                                    </div>
                                    <div id="floors_count"><input class="col-4" value="<?php echo e(request('floors_count')); ?>" name="floors_count"
                                                type="number" placeholder="تعداد طبقه"></div>

                                    <div id="estate_type">
                                        <select id="estate_type_dropdown" name="estate_type"
                                                class="form-select col-4">
                                            <option  value="">نوع ملک</option>

                                            <?php $__currentLoopData = \App\Models\estate_type::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(request("estate_type")==$estate->id): ?> selected
                                                        <?php endif; ?> value="<?php echo e($estate->id); ?>"><?php echo e($estate->name); ?></option>                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>


                                    <div class="form-group row row-cols-sm-2 row-cols-lg-2 mb-2">

                                        <div class="">
                                            <label for=""> از تلریخ:</label>
                                            <input autocomplete="off" name="from_date" id="from_date"
                                                   class="observer-example-alt"/>
                                        </div>
                                        <div class="">
                                            <label for=""> تا تاریخ :</label>
                                            <input autocomplete="off" name="to_date" id="to_date"
                                                   class="observer-example-alt"/>
                                        </div>


                                    </div>


                                    <div class="form-group row row-cols-sm-2 row-cols-lg-2 mb-2">

                                        <div class="">
                                            <label for=""> حداقل قیمت:</label>
                                            <input value="<?php echo e(request('min_price')); ?>" class="" type="number"
                                                   name="min_price">
                                        </div>
                                        <div class="">
                                            <label for=""> حداکثر قیمت:</label>
                                            <input value="<?php echo e(request("max_price")); ?>" class="" type="number"
                                                   name="max_price">
                                        </div>


                                    </div>

                                    <div id="area" class="form-group row row-cols-sm-2 row-cols-lg-2 mb-2">

                                        <div class="">
                                            <label for=""> حداقل متراژ زمین:</label>
                                            <input value="<?php echo e(request("min_area")); ?>" class="" type="number"
                                                   name="min_area">
                                        </div>
                                        <div class="">
                                            <label for=""> حداکثر متراژ زمین:</label>
                                            <input value="<?php echo e(request("max_area")); ?>" class="" type="number"
                                                   name="max_area">
                                        </div>


                                    </div>


                                    <div id="building_area" class="form-group row row-cols-sm-2 row-cols-lg-2 mb-2  ">

                                        <div class="">
                                            <label for=""> حداقل متراژ بنا:</label>
                                            <input value="<?php echo e(request("min_building_area")); ?>" class="" type="number"
                                                   name="min_building_area">
                                        </div>
                                        <div class="">
                                            <label for=""> حداکثر متراژ بنا:</label>
                                            <input value="<?php echo e(request("max_building_area")); ?>" class="" type="number"
                                                   name="max_building_area">
                                        </div>


                                    </div>


                                    <div id="options" class="text-center align-self-center">
                                        <br>
                                        <?php $__currentLoopData = \App\Models\Options::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check form-check-inline align-items-center ">


                                                <input
                                                    <?php if(request()->has('options')&&in_array($option->id, request('options'))): ?>
                                                    checked
                                                    <?php endif; ?>

                                                    class="form-check-input" type="checkbox" value="<?php echo e($option->id); ?>"
                                                    name="options[]"
                                                    id="defaultCheck1">
                                                <label class="form-check-label" for="defaultCheck1">
                                                    <?php echo e($option->name); ?>                                                </label>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>


                                    <div id="documents" class="text-center align-self-center">
                                        <br>
                                        <?php $__currentLoopData = \App\Models\document::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check form-check-inline align-items-center ">

                                                <input
                                                    <?php if(request()->has('documents')&&in_array($document->id, request('documents'))): ?>
                                                    checked
                                                    <?php endif; ?>
                                                    class="form-check-input" type="checkbox"
                                                    name="documents[]"
                                                    value="<?php echo e($document->id); ?>"
                                                    id="defaultCheck1">
                                                <label class="form-check-label" for="defaultCheck1">
                                                    <?php echo e($document->name); ?>                                                </label>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                                    <div id="condition" class="text-center align-self-center">
                                        <br>
                                        <?php $__currentLoopData = \App\Models\Conditions_type::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check form-check-inline align-items-center ">
                                                <input class="form-check-input" type="checkbox"
                                                       <?php if(request()->has('condition')&&in_array($condition->id, request('condition'))): ?>
                                                       checked
                                                       <?php endif; ?>
                                                       name="condition[]"
                                                       value="<?php echo e($condition->id); ?>"
                                                       id="defaultCheck1">
                                                <label class="form-check-label" for="defaultCheck1">
                                                    <?php echo e($condition->name); ?>                                                </label>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                                    <div id="used_type" class="text-center align-self-center">
                                        <br>
                                        <?php $__currentLoopData = \App\Models\Used_type::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $used): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check form-check-inline align-items-center ">
                                                <input class="form-check-input" type="checkbox"
                                                       <?php if(request()->has('used_type')&&in_array($used->id, request('used_type'))): ?>
                                                       checked
                                                       <?php endif; ?>
                                                       name="used_type[]"
                                                       value="<?php echo e($used->id); ?>"
                                                       id="defaultCheck1">
                                                <label class="form-check-label" for="defaultCheck1">
                                                    <?php echo e($used->name); ?>                                                </label>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>


                                    <div id="vila_option" class="text-center align-self-center">
                                        <br>
                                        <?php $__currentLoopData = \App\Models\vila_options::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-check form-check-inline align-items-center ">
                                                <input class="form-check-input" type="checkbox"
                                                       <?php if(request()->has('vila_option')&&in_array($options->id, request('vila_option'))): ?>
                                                       checked
                                                       <?php endif; ?>
                                                       name="vila_option[]"
                                                       value="<?php echo e($options->id); ?>"
                                                       id="defaultCheck1">
                                                <label class="form-check-label" for="defaultCheck1">
                                                    <?php echo e($options->name); ?>                                                </label>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>

                                </div>

                                <br>
                                <div class="row">

                                    <input id="search" type="submit" value="جستجو...">

                                </div>

                            </div>


                        </div>
                    </div>
                </form>
            </div>

            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <table class="table " style="direction: rtl">
                    <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col">شماره ملک</th>
                        <th scope="col"> نام مالک</th>
                        <th scope="col">تاریخ ثبت</th>
                        <th scope="col">نوع ملک</th>
                        <th scope="col">قیمت</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>

                            <th><img <?php if($estate->thumbnail!=null): ?> src="
                                       <?php echo e(asset('images/thumbnails/'.$estate->thumbnail)); ?> " <?php endif; ?> width="50"
                                     height="50"></th>
                            <th><?php echo e($estate->id); ?> <br></th>
                            <td><?php echo e($estate->owner_name); ?></td>
                            <td><?php echo e(\Morilog\Jalali\CalendarUtils::strftime('%Y-%m-%d', strtotime($estate->created_at))); ?></td>
                            <td><?php echo e($estate->estate_type->name); ?></td>
                            <td><?php echo e(number_format($estate->price)); ?></td>
                            <td>
                                <div class=""><a href="<?php echo e(route("get_estate",["id"=>$estate->id])); ?>"
                                                 type="button" class=" btn btn-outline-primary btn-sm">
                                        مشاهده</a>
                                    <a href=<?php echo e(route('update_estate_page',['id'=>$estate->id])); ?> type="button"
                                       class="btn btn-outline-success btn-sm"> ویرایش</a></div>

                            </td>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
            <?php echo e($estates->links()); ?>

            <div class="card-footer justify-content-evenly ">


            </div>
        </div>


    </div>




    <script>




        $(document).ready(function () {
            $('#city_dropdown').on('change', function () {
                $('#location_dropdown')
                    .find('option')
                    .remove()
                var value = $('#city_dropdown :selected').val();
                update_location(value);

            });
        });

        update_location(<?php echo e(request('city')); ?>);
        $("#location_dropdown").val(<?php echo e(request('location')); ?>);



        function update_location(value) {

            $.ajax({
                async: false,
                type: "GET",
                url: "../api/get_locations?city_id=" + value,
                success: function (response) {
                    $("#location_dropdown").append(new Option("یکی از منطقه هارا انتخاب کنید", ""));
                    response.forEach(function (location) {
                        $("#location_dropdown").append(new Option(location.name, location.id));
                    })

                }
            });
        }


        //lock estate_type
        <?php if(\request('lock')): ?>

        <?php switch(request("estate_type")):

        case (1): ?>
        aparteman()
        <?php break; ?>
        <?php case (2): ?>
        zamin()
        <?php break; ?>
        <?php case (3): ?>
        vila()
        <?php break; ?>

        <?php endswitch; ?>



        function zamin() {
            $("#building_area").attr('hidden', true);
            $("#options").attr('hidden', true);
            $("#vila_option").attr('hidden', true);
            $("#floors_count").attr('hidden', true);

        }

        function aparteman() {
            $("#area").attr('hidden', true);
            $("#building_type").attr('hidden', true);
            $("#used_type").attr('hidden', true);
            $("#vila_option").attr('hidden', true);
        }

        function vila() {
            $("#vila_option").attr('hidden', true);
            $("#floors_count").attr('hidden', true);

        }


        $("#estate_type").attr('hidden', true);



        <?php endif; ?>

        $('.observer-example-alt').persianDatepicker({
            observer: false,
            format: 'YYYY/MM/DD',
            altField: '.observer-example'
        });
        $("#from_date").val("<?php echo e(request('from_date')); ?>");
        $("#to_date").val("<?php echo e(request('to_date')); ?>");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\PhpstormProjects\amlak\resources\views/attract/estates.blade.php ENDPATH**/ ?>