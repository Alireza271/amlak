<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(__('پنل جذب')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="row row-cols-12">

                            <div class="row row-cols-12 m-1">

                                <?php $__currentLoopData = \App\Models\estate_type::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a  href="<?php echo e(route('search_estate',["estate_type"=>$item->id ,'lock'=>true])); ?>" type="button" class="col-3 btn btn-primary position-relative m-1">
                                        <?php echo e($item->name); ?>

                                        <span
                                            class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?php echo e($item->estate->count()); ?></span>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <div class="m-1">
                                <hr>


                                <button type="button" class="col-3 btn btn-primary position-relative m-1">
                                    امروز
                                    <span
                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?php echo e(Auth::user()->estate->where('created_at', '>=',\Carbon\Carbon::today())->count()); ?></span>
                                </button>

                                <button type="button" class="col-3 btn btn-primary position-relative m-1">
                                    7 روز گذشته
                                    <span
                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?php echo e(Auth::user()->estate->where('created_at', '>=',\Carbon\Carbon::today(-7))->count()); ?></span>
                                </button>

                                <button type="button" class="col-3 btn btn-primary position-relative m-1">

                                    ماه گذشته
                                    <span
                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?php echo e(Auth::user()->estate->where('created_at', '>=',\Carbon\Carbon::today(-30))->count()); ?></span>
                                </button>
                                <button type="button" class="col-3 btn btn-primary position-relative m-1">

                                    سال گذشته
                                    <span
                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?php echo e(Auth::user()->estate->where('created_at', '>=',date('Y-m-d (l, W)', strtotime("-1 year")))->count()); ?></span>
                                </button>

                            </div>


                            <div class="list-group" id="list-tab" role="">
                                <a class="list-group-item list-group-item-action" id="list-settings-list"
                                   href="<?php echo e(route('add_estate_page')); ?>" role="tab">ثبت ملک جدید</a>
                            </div>
                            <div class="col-12">
                                <div class="list-group position-relative" id="list-tab" role="">


                                    <a class="list-group-item " id="list-settings-list"
                                       href="<?php echo e(route('estates')); ?>" role="tab"> املاک ثبت شده</a>

                                    <span
                                        class="position-absolute top-50 start-0 translate-middle badge rounded-pill bg-danger"><?php echo e(Auth::user()->estate->count()); ?></span>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alireza\PhpstormProjects\amlak\resources\views/attract/attract.blade.php ENDPATH**/ ?>