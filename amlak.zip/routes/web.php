<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::prefix('Admin')->middleware("admin")->group(function () {
    Route::get('/', [App\Http\Controllers\AdminController::class, 'index'])->name('admin');
    Route::prefix("users")->group(function () {
        Route::get('/', [App\Http\Controllers\AdminController::class, 'users'])->name('users');
        Route::get('delete/{id}', [App\Http\Controllers\AdminController::class, 'delete_user'])->name('delete_user');
        Route::get('update/{id}', [App\Http\Controllers\AdminController::class, 'update_user_page'])->name('update_user_page');
        Route::post('update', [App\Http\Controllers\AdminController::class, 'update_user'])->name('update_user');
        Route::get('search', [App\Http\Controllers\AdminController::class, 'search_user'])->name('search_user');
    });


});


Route::prefix("attract")->middleware("attract")->group(function () {
    Route::get('/', [App\Http\Controllers\AttractController::class, 'index'])->name('attract');
    Route::get('add_estate', [App\Http\Controllers\AttractController::class, 'add_estate_page'])->name('add_estate_page');
    Route::post('add_estate', [App\Http\Controllers\AttractController::class, 'add_estate'])->name('add_estate');
    Route::get('estates', [App\Http\Controllers\AttractController::class, 'estates'])->name('estates');
    Route::get('update/{id}', [App\Http\Controllers\AttractController::class, 'update_estate_page'])->name('update_estate_page');
    Route::post('update', [App\Http\Controllers\AttractController::class, 'update_estate'])->name('update_estate');
    Route::get('get/{id}', [App\Http\Controllers\AttractController::class, 'get_estate'])->name('get_estate');
    Route::get('search_estate', [App\Http\Controllers\AttractController::class, 'search_estate'])->name('search_estate');



});
Route::prefix("circulation")->middleware("circulation")->group(function () {
    Route::get('/', [App\Http\Controllers\circulationController::class, 'index'])->name('circulation');


});

