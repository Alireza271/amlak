<?php

namespace App\Http\Controllers;

use App\Models\estate;
use App\Models\Estate_Images;
use App\Models\Options;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Morilog\Jalali\CalendarUtils;
use Morilog\Jalali\Jalalian;
use function PHPUnit\Framework\isNull;

class AttractController extends Controller
{
    public function index()
    {
        return view('attract.attract');
    }

    public function add_estate_page()
    {
        return view("attract.add_estate");
    }

    public function add_estate(Request $request)
    {

        $estate = estate::create([
            "estate_type_id" => $request->get('estate_type'),
            "estate_location_type_id" => $request->get('estate_location_type'),
            "building_type_id" => $request->get('building_type'),
            "city_id" => $request->get('city'),
            "location_id" => $request->get('location'),
            "user_id" => Auth::id(),
            "owner_name" => $request->get('owner_name'),
            "owner_phone" => $request->get('owner_phone'),
            "area" => $request->get('area'),
            "building_area" => $request->get('building_area'),
            "building_date" => $request->get('build_date'),
            "price" => $request->get('price'),
            "length" => $request->get('length'),
            "width" => $request->get('width'),
            "description" => $request->get('description'),
            "address" => $request->get('address'),
            "floors_count" => $request->get('floors_count'),
            "floors" => $request->get('floors'),
            "module" => $request->get('module'),
        ]);


        $estate->fresh()->used_type()->attach($request->get('used_type'));
        $estate->fresh()->conditions_type()->attach($request->get('condition'));
        $estate->fresh()->documents()->attach($request->get('document'));
        $estate->fresh()->options()->attach($request->get('option'));
        $estate->fresh()->vila_options()->attach($request->get('vila_option'));
        $i = true;

        if ($request->has("image")) {
            foreach ($request->file('image') as $file) {

                $fileName = time() . '.' . $file->getClientOriginalName();

                if ($i) {
                    $img = Image::make($file->getRealPath())->resize(100, 100);
                    $img->save(public_path('images/thumbnails/' . $fileName), 80);

                    $estate->thumbnail = $fileName;
                    $estate->save();
                    $i = false;
                }
                $file->move(public_path('images'), $fileName);

                $estate->fresh()->images()->create([
                        'file_name' => $fileName,
                    ]
                );
            }

        }

        return redirect(route('add_estate_page', ["status" => 'ok']));

    }


    public function estates()
    {
        $estates = Auth::user()->estate()->Paginate(10);


        return view('attract.estates', compact("estates"));
    }

    public function update_estate_page($id)
    {
        $estate = Auth::user()->estate->find($id);
        return view("attract.update_estate", compact('estate'));
    }

    public function update_estate(Request $request)
    {
        $estate = Auth::user()->estate->find($request->get('estate_id'));
        $estate->update(
            [
                "estate_type_id" => $request->get('estate_type'),
                "building_type_id" => $request->get('building_type'),
                "city_id" => $request->get('city'),
                "location_id" => $request->get('location'),
                "owner_name" => $request->get('owner_name'),
                "owner_phone" => $request->get('owner_phone'),
                "area" => $request->get('area'),
                "building_area" => $request->get('building_area'),
                "building_date" => $request->get('build_date'),
                "price" => $request->get('price'),
                "length" => $request->get('length'),
                "width" => $request->get('width'),
                "description" => $request->get('description'),
                "address" => $request->get('address'),
                "floors_count" => $request->get('floors_count'),
                "floors" => $request->get('floors'),
                "module" => $request->get('module'),
            ]
        );
        $estate->fresh()->used_type()->detach();
        $estate->fresh()->used_type()->attach($request->get('used_type'));

        $estate->fresh()->conditions_type()->detach();
        $estate->fresh()->conditions_type()->attach($request->get('condition'));

        $estate->fresh()->documents()->detach();
        $estate->fresh()->documents()->attach($request->get('document'));

        $estate->fresh()->options()->detach();
        $estate->fresh()->options()->attach($request->get('option'));

        $estate->fresh()->vila_options()->detach();
        $estate->fresh()->vila_options()->attach($request->get('vila_option'));
        return redirect(route('update_estate_page', ["status" => 'ok', 'id' => $request->get('estate_id')]));
    }

    public function get_estate($id)
    {
        $estate = Auth::user()->estate->find($id);

        return view("attract.get_estate", compact("estate"));
    }

    public function search_estate(Request $request)
    {
        $query = $request->get("query");
        $city = $request->get("city");
        $location = $request->get("location");
        $estate_type = $request->get("estate_type");
        $from_date = $request->get("from_date");
        $to_date = $request->get("to_date");

        $min_area = $request->get("min_area");
        $max_area = $request->get("max_area");

        $min_building_area = $request->get("min_building_area");
        $max_building_area = $request->get("max_building_area");

        $min_price = $request->get("min_price");
        $max_price = $request->get("max_price");

        $filter = estate::query();
        $get_by_id = estate::where('user_id', Auth::id())->where("id", $query);
        $estates = null;
        if ($get_by_id->get() != '[]') {
            $filter = $get_by_id;
        } else {

            if ($query != null) {
                $filter = $filter->orWhere([["owner_phone", 'LIKE', '%' . $query . '%'], ['user_id', Auth::id()]])
                    ->orWhere([["owner_name", "LIKE", '%' . $query . '%'], ['user_id', Auth::id()]])
                    ->orWhere([["description", "LIKE", '%' . $query . '%'], ['user_id', Auth::id()]]);
            } else {
                if ($city != null) {
                    error_log('city');

                    $filter = $filter->where("city_id", $city);
                }

                if (\request("estate_location_type") != null) {
                    error_log('estate_location_type');

                    $filter = $filter->where("estate_location_type_id", \request("estate_location_type"));
                }

                if (\request("building_type") != null) {
                    error_log('building_type');

                    $filter = $filter->where("building_type_id", \request("building_type"));
                }
                if (\request("floors_count") != null) {
                    error_log('floors_count');

                    $filter = $filter->where("floors_count", \request("floors_count"));
                }


                if ($location != null) {
                    error_log('location');

                    $filter = $filter->where("location_id", $location);

                }

                if ($estate_type != null) {
                    error_log('estate_type');

                    $filter = $filter->where("estate_type_id", $estate_type);

                }


                //area
                if ($min_area != null) {
                    error_log('area.');

                    $filter = $filter->where('area', '>=', (int)$min_area);
                }

                if ($max_area != null) {
                    error_log('max area');

                    $filter = $filter->where('area', '<=', (int)$max_area);
                }
                //end_area


                //  //building_area
                if ($min_building_area != null) {
                    error_log('Smin building');

                    $filter = $filter->where('building_area', '>=', (int)$min_building_area);
                }

                if ($max_building_area != null) {
                    error_log('max building.');

                    $filter = $filter->where('building_area', '<=', (int)$max_building_area);
                }
                //end_building_area


                //price
                if ($min_price != null) {

                    $filter = $filter->where('price', '>=', (int)$min_price);
                }

                if ($max_price != null) {
                    error_log('max price');

                    $filter = $filter->where('price', '<=', (int)$max_price);
                }
                //end_price


                ///////// checkBoxs

                if ($request->has('options')) {

                    foreach (\request('options') as $item) {
                        $filter = $filter->whereHas('options', function ($query) use ($item) {
                            $query->where('options_id', $item);
                        });
                    }


                }

                if ($request->has('documents')) {

                    foreach (\request('documents') as $item) {
                        $filter = $filter->whereHas('documents', function ($query) use ($item) {
                            $query->where('document_id', $item);
                        });
                    }


                }

                if ($request->has('condition')) {

                    foreach (\request('condition') as $item) {
                        $filter = $filter->whereHas('conditions_type', function ($query) use ($item) {
                            $query->where('conditions_type_id', $item);
                        });
                    }


                }

                if ($request->has('used_type')) {

                    foreach (\request('used_type') as $item) {
                        $filter = $filter->whereHas('used_type', function ($query) use ($item) {
                            $query->where('used_type_id', $item);
                        });
                    }


                }
                if ($request->has('vila_option')) {

                    foreach (\request('vila_option') as $item) {
                        $filter = $filter->whereHas('vila_options', function ($query) use ($item) {
                            $query->where('vila_options_id', $item);
                        });
                    }


                }


                ////////end checkboxs

                if ($from_date != null) {
                    $from_date = CalendarUtils::createCarbonFromFormat('Y/m/d', CalendarUtils::convertNumbers($request->get("from_date"), true))->format('Y-m-d'); //2016-05-8
                    $to_date = CalendarUtils::createCarbonFromFormat('Y/m/d', CalendarUtils::convertNumbers(($request->get("to_date") == null) ? Jalalian::forge('last sunday')->format('Y/m/d') : $request->get("to_date"), true))->format('Y-m-d');
                    $filter = $filter->whereBetween("created_at", [$from_date, $to_date]);
                }
            }


        }
        $estates = $filter->paginate(10);
        $estates->appends($request->all())->links();
//
//
////        return Auth::user()->estate->whereBetween("created_at",[$from_date,$to_date]);
//        $estates = $estates->get();
        return view('attract.estates', compact("estates"));

    }


}
