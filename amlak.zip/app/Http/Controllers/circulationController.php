<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class circulationController extends Controller
{
    public function index()
    {
        return view('circulation.circulation');
    }
}
