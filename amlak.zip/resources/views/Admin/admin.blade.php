@extends('layouts.app')


@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('پنل ادمین') }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif


                            <div class="row">
                                <div class="col-12">
                                    <div class="list-group" id="list-tab" role="">
                                        <a class="list-group-item list-group-item-action" id="list-settings-list"  href="{{route('register')}}" role="tab" >ثبت کاربر جدید</a>
                                        <a class="list-group-item list-group-item-action" id="list-settings-list"  href="{{route('users')}}" role="tab" >نمایش کاربران</a>
                                    </div>
                                </div>
                            </div>



                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
