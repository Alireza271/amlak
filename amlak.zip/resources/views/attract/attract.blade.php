@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">{{ __('پنل جذب') }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <div class="row row-cols-12">

                            <div class="row row-cols-12 m-1">

                                @foreach(\App\Models\estate_type::all() as $item)
                                    <a  href="{{route('search_estate',["estate_type"=>$item->id ,'lock'=>true])}}" type="button" class="col-3 btn btn-primary position-relative m-1">
                                        {{$item->name}}
                                        <span
                                            class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">{{$item->estate->count()}}</span>
                                    </a>
                                @endforeach

                            </div>
                            <div class="m-1">
                                <hr>


                                <button type="button" class="col-3 btn btn-primary position-relative m-1">
                                    امروز
                                    <span
                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">{{Auth::user()->estate->where('created_at', '>=',\Carbon\Carbon::today())->count()}}</span>
                                </button>

                                <button type="button" class="col-3 btn btn-primary position-relative m-1">
                                    7 روز گذشته
                                    <span
                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">{{Auth::user()->estate->where('created_at', '>=',\Carbon\Carbon::today(-7))->count()}}</span>
                                </button>

                                <button type="button" class="col-3 btn btn-primary position-relative m-1">

                                    ماه گذشته
                                    <span
                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">{{Auth::user()->estate->where('created_at', '>=',\Carbon\Carbon::today(-30))->count()}}</span>
                                </button>
                                <button type="button" class="col-3 btn btn-primary position-relative m-1">

                                    سال گذشته
                                    <span
                                        class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">{{Auth::user()->estate->where('created_at', '>=',date('Y-m-d (l, W)', strtotime("-1 year")))->count()}}</span>
                                </button>

                            </div>


                            <div class="list-group" id="list-tab" role="">
                                <a class="list-group-item list-group-item-action" id="list-settings-list"
                                   href="{{route('add_estate_page')}}" role="tab">ثبت ملک جدید</a>
                            </div>
                            <div class="col-12">
                                <div class="list-group position-relative" id="list-tab" role="">


                                    <a class="list-group-item " id="list-settings-list"
                                       href="{{route('estates')}}" role="tab"> املاک ثبت شده</a>

                                    <span
                                        class="position-absolute top-50 start-0 translate-middle badge rounded-pill bg-danger">{{Auth::user()->estate->count()}}</span>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
