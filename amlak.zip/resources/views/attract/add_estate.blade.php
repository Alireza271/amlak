@extends('layouts.app')

@section('content')


    <div class="container" style="direction: rtl ">
        <div class="row justify-content-center">
            <div class="col-md-8">
                @if(isset($_GET['status']))
                    <div class="alert alert-success" role="alert">
                        ثبت ملک با موفقیت انجام شد!
                    </div>
                @endif
                <div class="card">
                    <div class="card-header">{{ __('افزودن ملک') }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif
                        <form id="amlak" action="{{route('add_estate')}}" class="form-group " method="post" enctype="multipart/form-data">
                            {{csrf_field()}}
                            <div class=" ">



                                @foreach(\App\Models\estate_type::all() as $type)

                                    <div class="form-check-inline">
                                        <input class="form-check-input" type="radio" required name="estate_type"
                                               value="{{$type->id}}">
                                        <label class="form-check-label" for="flexRadioDefault1">
                                            {{$type->name}}
                                        </label>
                                    </div>
                                @endforeach


                                    <div id="building_type" class=" ">
<br>
                                        @foreach(\App\Models\building_type::all() as $type)

                                            <div class="form-check-inline">
                                                <input class="form-check-input" type="radio" name="building_type"
                                                       value="{{$type->id}}">
                                                <label class="form-check-label" for="flexRadioDefault1">
                                                    {{$type->name}}
                                                </label>
                                            </div>
                                        @endforeach

                                    </div>

                                <div id="estate_location_type" >
                                    <br>

                                    @foreach(\App\Models\Estate_Location_type::all() as $type)

                                        <div class="form-check-inline">
                                            <input id="estate_location_type" class="form-check-input" type="radio"  name="estate_location_type"
                                                   value="{{$type->id}}">
                                            <label class="form-check-label" for="flexRadioDefault1">
                                                {{$type->name}}
                                            </label>
                                        </div>
                                    @endforeach
                                </div>


                                <br>
                                <div id="city" class=" row ">

                                    <label class="form-check-label ">
                                        شهر:
                                    </label>
                                    <select id="city_dropdown" name="city" class="form-select col-4" required>
                                        <option value="">یکی از گزینه هارا انتخاب کنید</option>

                                        @foreach(\App\Models\City::all() as $city)
                                            <option value="{{$city->id}}">{{$city->name}}</option>
                                        @endforeach
                                    </select> <label class="form-check-label ">
                                        منطقه:
                                    </label>
                                    <select id="location_dropdown" name="location" class="form-select col-4" required
                                            aria-label="Default select example">
                                    </select>

                                </div>
                                <br>

                            </div>
                            <br>
                            <div id="owner_name" class=" row ">

                                <label class="form-check-label ">
                                    نام مالک:
                                </label>
                                <div class="col-8">
                                    <input type="text" name="owner_name" class="form-control">
                                </div>
                            </div>

                            <div id="owner_phone" class=" row ">

                                <label class="form-check-label ">
                                    شماره مالک:
                                </label>
                                <div class="col-8">
                                    <input type="number" name="owner_phone" class="form-control">
                                </div>
                            </div>
                            <br>
                            <hr>
                            <div class=" row " id="area">

                                <label class="form-check-label ">
                                    متراژ زمین:
                                </label>
                                <div class="col-8">
                                    <input type="number" name="area" class="form-control">
                                </div>
                            </div>
                            <br>
                            <div class=" row " id="building_area">

                                <label class="form-check-label ">
                                    متراژ بنا:
                                </label>
                                <div class="col-8">
                                    <input type="number" name="building_area" class="form-control"
                                           id="building_area">
                                </div>
                            </div>
                            <br>

                            <div id="used_type">
                                <hr>
                                <label>
                                    نوع کاربری:
                                </label>
                                @foreach(\App\Models\Used_type::all() as $Used_type)
                                    <div class="form-check ">
                                        <input class="form-check-input" name="used_type[]" type="checkbox"
                                               value="{{$Used_type->id}}">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            {{$Used_type->name}}
                                        </label>
                                    </div>
                                @endforeach
                            </div>

                            <div id="vila_option" class=" justify-content-around">

                                <hr>
                                <label>
                                    نوع ویلا:
                                </label>
                                @foreach(\App\Models\vila_options::all() as $option)
                                    <div class="form-check ">
                                        <input class="form-check-input" name="vila_option[]" type="checkbox"
                                               value="{{$option->id}}">
                                        <label class="form-check-label" for="flexCheckDefault">
                                            {{$option->name}}
                                        </label>
                                    </div>
                                @endforeach
                            </div>

                            <div class="" id="floors_count">
                                <hr>
                                <label class="form-check-label ">
                                    تعداد طبقات:
                                </label>
                                <div class="col-8">
                                    <input type="number" name="floors_count" class="form-control">
                                </div>
                            </div>

                            <div class="" id="module">

                                <label class="form-check-label ">
                                    واحد:
                                </label>
                                <div class="col-8">
                                    <input type="number" name="module" class="form-control">
                                </div>
                            </div>


                            <div class="" id="floors">

                                <label class="form-check-label ">
                                    طبقه چندم:
                                </label>
                                <div class="col-8">
                                    <input type="number" name="floors" class="form-control">
                                </div>
                            </div>
                            <br>
                            <hr>
                            <div id="space" class="row justify-content-around">


                                <div class="row"><label class=" ">
                                        طول:
                                    </label>
                                    <input type="number" name="length" class="form-control">
                                </div>
                                <div class="row"><label class="form-check-label ">
                                        عرض:
                                    </label>
                                    <input type="number" name="width" class="form-control" id="width">
                                </div>
                            </div>


                            <hr>

                                <div id="options"><label>
                                        مشاعات:
                                    </label>
                                    @foreach(\App\Models\Options::all() as $option)
                                        <div class="form-check ">
                                            <input class="form-check-input" name="option[]" type="checkbox"
                                                   value="{{$option->id}}">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                {{$option->name}}
                                            </label>
                                        </div>
                                    @endforeach
                                </div>


                                <div id="condition" >
                                    <label>
                                        شرایط قیمت:
                                    </label>
                                    @foreach(\App\Models\Conditions_type::all() as $Condition)
                                        <div class="form-check ">
                                            <input class="form-check-input" name="condition[]" type="checkbox"
                                                   value="{{$Condition->id}}" >
                                            <label class="form-check-label" for="flexCheckDefault">
                                                {{$Condition->name}}
                                            </label>
                                        </div>
                                    @endforeach
                                </div>


                            <hr>
                            <div id="price" class="row">

                                <label class="form-check-label ">
                                    قیمت:
                                </label>
                                <div class="col-8 ">
                                    <div class="input-group mb-3">
                                        <input name="price" type="number" class="form-control"
                                               aria-label="Recipient's username" aria-describedby="basic-addon2">
                                        <span class="input-group-text" id="basic-addon2">تومان</span>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div id="documents">
                                <label>
                                    مدارک:
                                </label>
                                @foreach(\App\Models\document::all() as $document)
                                    <div class="form-check ">
                                        <input class="form-check-input" name="document[]" type="checkbox"
                                               value="{{$document->id}}" >
                                        <label class="form-check-label" for="flexCheckDefault">
                                            {{$document->name}}
                                        </label>
                                    </div>
                                @endforeach
                            </div>
                            <br>
                            <div class=" row " id="build_date">

                                <label class="form-check-label ">
                                    سال ساخت:
                                </label>
                                <div class="col-8 ">
                                    <div class="input-group mb-3">
                                        <input type="number" name="build_date" class="form-control" max="1400"
                                               min="1200"
                                               aria-label="Recipient's username" aria-describedby="basic-addon2">
                                    </div>
                                </div>
                            </div>

                            <div id="description" class=" row ">

                                <label class="form-check-label ">
                                    توضیحات:
                                </label>
                                <div class="col-8 ">
                                    <div class="input-group mb-3">
                                        <textarea type="" name="description" class="form-control "> </textarea>
                                    </div>
                                </div>
                            </div>

                            <div class=" row " id="address" disabled>

                                <label class="form-check-label ">
                                    آدرس و کروکی:
                                </label>
                                <div class="col-8 ">
                                    <div class="input-group mb-3">
                                        <textarea name="address" class="form-control "> </textarea>
                                    </div>
                                </div>
                            </div>

                            <div id="images" class="row ">

                                <label class="form-check-label ">
                                    بارگذاری تصویر:
                                </label>
                                <div class="col-8 ">
                                    <div class="input-group mb-3">
                                        <input type="file" name="image[]" class="form-control " multiple>
                                    </div>
                                </div>
                            </div>

                            <input class="btn-success btn w-25" type="submit" value="ثبت">
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">


            $(document).ready(function () {

                $('#amlak').on('change', function () {
                    var estate_type = $('input[name=estate_type]:checked', '#amlak').val();
                    console.log(estate_type);
                    refresh();


                    if (estate_type == 1) {
                        aparteman();
                    }
                    if (estate_type == 2) {
                        zamin();
                    }
                    if (estate_type == 3) {
                        vila();
                    }

                });
            });
            $(document).ready(function () {
                $('#city_dropdown').on('change', function () {
                    $('#location_dropdown')
                        .find('option')
                        .remove()
                    var value = $('#city_dropdown :selected').val();

                    $.ajax({
                        type: "GET",
                        url: "../api/get_locations?city_id=" + value,
                        success: function (response) {
                            response.forEach(function (location) {
                                $("#location_dropdown").append(new Option(location.name, location.id));
                            })

                        }
                    });
                });
            });


            function zamin() {
                $("#building_area :input").attr("disabled", true);
                $("#building_area").attr("hidden", true);

                $("#floors_count :input").attr("disabled", true);
                $("#floors_count").attr("hidden", true);

                $("#floors :input").attr("disabled", true);
                $("#floors").attr("hidden", true);

                $("#module :input").attr("disabled", true);
                $("#module").attr("hidden", true);

                $("#options :input").attr("disabled", true);
                $("#options").attr("hidden", true);

                $("#vila_option :input").attr("disabled", true);
                $("#vila_option").attr("hidden", true);

                $("#build_date :input").attr("disabled", true);
                $("#build_date").attr("hidden", true);

            }

            function aparteman() {

                $("#area :input").attr("disabled", true);
                $("#area").attr("hidden", true);

                $("#vila_option :input").attr("disabled", true);
                $("#vila_option").attr("hidden", true);

                $("#building_type :input").attr("disabled", true);
                $("#building_type").attr("hidden", true);

                $("#used_type :input").attr("disabled", true);
                $("#used_type").attr("hidden", true);

                $("#space :input").attr("disabled", true);
                $("#space").attr("hidden", true);



            }

            function vila() {
                $("#estate_location_type :input").attr("disabled",true);
                $("#estate_location_type").attr("hidden",true);

                $("#floors_count").attr("hidden", true);
                $("#floors_count :input").attr("disabled", true);

                $("#floors :input").attr("disabled", true);
                $("#floors").attr("hidden", true);

                $("#module :input").attr("disabled", true);
                $("#module").attr("hidden", true);

                $("#space :input").attr("disabled", true);
                $("#space").attr("hidden", true);

                $("#used_type :input").attr("disabled", true);
                $("#used_type").attr("hidden", true);

                $("#build_date :input").attr("disabled", true);
                $("#build_date").attr("hidden", true);
            }


            function refresh() {
                $("#estate_location_type :input").attr("disabled",false);
                $("#estate_location_type").attr("hidden",false);

                $("#building_area :input").attr("disabled", false);
                $("#building_area").attr("hidden", false);

                $("#floors_count :input").attr("disabled", false);
                $("#floors_count").attr("hidden", false);

                $("#floors :input").attr("disabled", false);
                $("#floors").attr("hidden", false);

                $("#module :input").attr("disabled", false);
                $("#module").attr("hidden", false);

                $("#options :input").attr("disabled", false);
                $("#options").attr("hidden", false);


                $("#build_date :input").attr("disabled", false);
                $("#build_date").attr("hidden", false);

                $("#area :input").attr("disabled", false);
                $("#area").attr("hidden", false);


                $("#building_type :input").attr("disabled", false);
                $("#building_type").attr("hidden", false);

                $("#used_type :input").attr("disabled", false);
                $("#used_type").attr("hidden", false);

                $("#space :input").attr("disabled", false);
                $("#space").attr("hidden", false);

                $("#vila_option :input").attr("disabled", false);
                $("#vila_option").attr("hidden", false);
            }


        </script>
@endsection

