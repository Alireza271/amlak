<?php

namespace Database\Seeders;

use App\Models\estate;
use Faker\Factory;
use Illuminate\Database\Seeder;

class estateTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Factory::create();
        $count = 100;
        for ($i = 0; $i < $count; $i++) {

            estate::create([
                "estate_type_id" => rand(1, 3),
                "building_type_id" => rand(1, 2),
                "city_id" => rand(1, 2),
                "location_id" => rand(1, 3),
                "user_id" => "1",
                "owner_phone" => rand(9116040200, 9116040264),
                "owner_name" => $faker->name,
                "area" => rand(50, 5000),
                "building_area" => rand(50, 100),
                "building_date" => rand(1320, 1400),
                "price" => rand(500, 1500),
                "length" => rand(10, 200),
                "width" => rand(10, 200),
                "description" => $faker->text,
                "address" => $faker->address,
                "created_at" => $faker->dateTime

            ]);

        }
    }
}
